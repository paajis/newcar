package com.infotech.service.impl;

import java.util.List;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infotech.dao.StudentDAO;
import com.infotech.model.FindArideModel;
import com.infotech.model.OfferArideModel;
import com.infotech.model.registermodal;
import com.infotech.service.StudentService;

@Service("studentService")
public class StudentServiceImpl implements StudentService {
	
	@Autowired
	private StudentDAO studentDAO;
	
	public void setStudentDAO(StudentDAO studentDAO) {
		this.studentDAO = studentDAO;
	}
	
	public StudentDAO getStudentDAO() {
		return studentDAO;
	}
	
	public boolean registerStudent(registermodal student) {
						
			boolean saveStudent = getStudentDAO().saveStudent(student);
			
			if(saveStudent)
				return saveStudent;
						
		return false;
	}

	
	public boolean validateStudentCredential(String email, String password) {
		boolean flag=true;
		flag=getStudentDAO().getStudentDetailsByEmailAndPassword(email, password);
		return flag;
	}

	
	public boolean registerRide(FindArideModel ride) {
		
       boolean flag=false;
       Random ran=new Random();
       ride.setFindid(Integer.toString(ran.nextInt(((89999)+1)+10000)));
       flag=getStudentDAO().saveRide(ride);
		return flag;
	}

	public boolean registerOffer(OfferArideModel offer) {
	
		 boolean flag=false;
		 Random ran=new Random();
	       offer.setOfferid(Integer.toString(ran.nextInt(((89999)+1)+10000)));
	       flag=getStudentDAO().saveOffer(offer);
			return flag;
	}

	public boolean emailValidation(String email) {
		if(getStudentDAO().emailValidation(email))
		{ 
			return true;
		}
		return false;
	}

	public List<OfferArideModel> getInfoFromDB() {
	  List<OfferArideModel> list=getStudentDAO().getInfoFromDB();
		return list;
	}
}
