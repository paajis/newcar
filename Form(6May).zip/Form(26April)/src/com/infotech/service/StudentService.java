package com.infotech.service;


import java.util.List;

import com.infotech.model.FindArideModel;
import com.infotech.model.OfferArideModel;
import com.infotech.model.registermodal;

public interface StudentService {
	public abstract boolean validateStudentCredential(String email,String password);
	public abstract boolean registerStudent(registermodal student);
	public abstract boolean emailValidation(String email);
    public abstract boolean registerRide(FindArideModel ride);
    public abstract boolean registerOffer(OfferArideModel offer);
    public abstract List<OfferArideModel> getInfoFromDB();
}