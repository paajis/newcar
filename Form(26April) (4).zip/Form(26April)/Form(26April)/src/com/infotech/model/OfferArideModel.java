package com.infotech.model;


	
	import javax.persistence.Entity;
	import javax.persistence.GeneratedValue;
	import javax.persistence.Id;
	import javax.persistence.Table;
	import javax.validation.constraints.Pattern;
	import javax.validation.constraints.Size;

	import org.hibernate.validator.constraints.NotEmpty;
	@Entity
	@Table(name="offerRegister")
	public class OfferArideModel {
		@Id
		@GeneratedValue
		private Integer id;
		
		public Integer getId() {
			return id;
		}
		
		private String offerid;
		
		public String getOfferid() {
			return offerid;
		}

		public void setOfferid(String offerid) {
			this.offerid = offerid;
		}

		@NotEmpty(message="PickupAddress  must not be blank")
		private String pickupaddress;
		
		@NotEmpty(message="PickupDescription  must not be blank")
		private String pickupdescription;
				
		
		@NotEmpty(message="DropAddress must not be blank")
		private String dropaddress;
		
		@NotEmpty(message="DropDescription  must not be blank")
		private String dropdescription;
		
		@NotEmpty(message="Time must not be blank")
		private String time;
		
		@NotEmpty(message="Seats must not be blank")
		private String vacancy;

		public String getPickupaddress() {
			return pickupaddress;
		}

		public void setPickupaddress(String pickupaddress) {
			this.pickupaddress = pickupaddress;
		}

		public String getPickupdescription() {
			return pickupdescription;
		}

		public void setPickupdescription(String pickupdescription) {
			this.pickupdescription = pickupdescription;
		}

		public String getDropaddress() {
			return dropaddress;
		}

		public void setDropaddress(String dropaddress) {
			this.dropaddress = dropaddress;
		}

		public String getDropdescription() {
			return dropdescription;
		}

		public void setDropdescription(String dropdescription) {
			this.dropdescription = dropdescription;
		}

		public String getTime() {
			return time;
		}

		public void setTime(String time) {
			this.time = time;
		}

		public String getVacancy() {
			return vacancy;
		}

		public void setVacancy(String vacancy) {
			this.vacancy = vacancy;
		}

		

		

		
		
		
		

	}



