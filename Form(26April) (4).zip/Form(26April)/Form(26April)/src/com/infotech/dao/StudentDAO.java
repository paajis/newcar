package com.infotech.dao;

import com.infotech.model.FindArideModel;
import com.infotech.model.OfferArideModel;
import com.infotech.model.registermodal;

public interface StudentDAO {
	public abstract boolean saveStudent(registermodal student);
	public boolean emailValidation(String email);
	public boolean getStudentDetailsByEmailAndPassword(String email,String password);
	public boolean saveRide(FindArideModel ride);
	public boolean saveOffer(OfferArideModel offer);
}
